package com.tweetapp.util;

public class TweetAppCustomException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TweetAppCustomException(String s){  
		System.out.println(s);
	 }  
}
